// EvidenceSubmitForm.js
import React, { useState } from 'react';
import './evidencesubmit.css';

const EvidenceSubmitForm = () => {
  const [evidenceId, setEvidenceId] = useState('');
  const [CaseeId, setCaseeId] = useState('');
  const [contentType, setContentType] = useState('');
  const [mediaFile, setMediaFile] = useState(null);

  const handleEvidenceSubmit = () => {
    // Handle evidence submission logic here
  };

  return (
    <div className="evidence-submit-form-container">
      <form className="evidence-submit-form">
        <h2>Evidence Submission</h2>
        <div className="form-group">
          <label>Evidence ID</label>
          <input
            type="text"
            placeholder="Evidence ID"
            value={evidenceId}
            onChange={(e) => setEvidenceId(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>Case ID</label>
          <input
            type="text"
            placeholder="Case ID"
            value={CaseeId}
            onChange={(e) => setCaseeId(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>Content Type</label>
          <select value={contentType} onChange={(e) => setContentType(e.target.value)}>
            <option value="">Select content type</option>
            <option value="image">Image</option>
            <option value="audio">Audio</option>
            <option value="video">Video</option>
            <option value="document">Document</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div className="form-group">
          <label>Upload Media</label>
          <input
            type="file"
            accept="image/*, audio/*, video/*"
            onChange={(e) => setMediaFile(e.target.files[0])}
          />
        </div>
        <button onClick={handleEvidenceSubmit}>Submit Evidence</button>
      </form>
    </div>
  );
};

export default EvidenceSubmitForm;
