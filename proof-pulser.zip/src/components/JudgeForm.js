// JudgeForm.js
import React, { useState } from 'react';
import './JudgeForm.css'; // Import your CSS file

const JudgeForm = () => {
  const [caseId, setCaseId] = useState('');
  const [approval, setApproval] = useState('');

  const handleJudgeAction = () => {
    // Handle judge action logic here (e.g., send the decision to the server)
  };

  return (
    <div className="judge-form-container">
      <form className="judge-form">
        <h2>Judge Page</h2>
        <div className="form-group">
          <label>Case ID</label>
          <input
            type="text"
            placeholder="Case ID"
            value={caseId}
            onChange={(e) => setCaseId(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>Approval</label>
          <select value={approval} onChange={(e) => setApproval(e.target.value)}>
            <option value="">Select approval status</option>
            <option value="approve">Approve</option>
            <option value="reject">Reject</option>
            <option value="fetchdata">Fetch-Data</option>
          </select>
        </div>
        <button onClick={handleJudgeAction}>Submit Decision</button>
      </form>
    </div>
  );
};

export default JudgeForm;
